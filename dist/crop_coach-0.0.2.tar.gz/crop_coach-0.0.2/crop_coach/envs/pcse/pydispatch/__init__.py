"""Multi-consumer multi-producer dispatching mechanism
"""
__version__ = "2.0.3"
__author__ = "Patrick K. O'Brien"
__license__ = "BSD-style, see license.txt for details"

